/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exec_cmd.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akkolitozer <akkolitozer@student.42.fr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/03 15:44:08 by nmeunier          #+#    #+#             */
/*   Updated: 2026/08/05 23:26:31 by akkolitozer      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	cmd_not_found(char *args)
{
	ft_putstr_fd("minishell: ", 2);
	if (args)
		ft_putstr_fd(args, 2);
	ft_putstr_fd(": command not found\n", 2);
	exit(127);
}

void	exec_cmd(t_cmd *cmd, char **env)
{
	char	*path;

	if (!cmd->args || !cmd->args[0] || cmd->args[0][0] == '\0')
		cmd_not_found(NULL);
	path = get_path(cmd->args[0], env);
	if (!path)
		cmd_not_found(cmd->args[0]);
	execve(path, cmd->args, env);
	if (errno == EISDIR)
	{
		ft_putstr_fd("minishell: ", 2);
		ft_putstr_fd(cmd->args[0], 2);
		ft_putstr_fd(": Is a directory\n", 2);
	}
	else if (errno == EACCES || errno == ENOEXEC)
	{
		ft_putstr_fd("minishell: ", 2);
		ft_putstr_fd(cmd->args[0], 2);
		ft_putstr_fd(": Permission denied\n", 2);
	}
	else
		ft_putstr_fd("minishell: execve failed\n", 2);
	exit(126);
}
